enum MenuState { home, favorite, message, profile }
