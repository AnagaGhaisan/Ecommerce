List<Map<String, String>> splashData = [
  {"image": "assets/images/splash_1.png"},
  {"image": "assets/images/splash_2.png"},
  {"image": "assets/images/splash_3.png"},
];

